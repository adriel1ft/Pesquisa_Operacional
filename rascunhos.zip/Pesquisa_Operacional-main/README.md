# 🎯 Projeto Branch and Bound

## Sobre o projeto
>> Pendente <<

## Stacks utilizadas
1. Python

## Materiais de apoio
[Aprendenda a Técnica](https://awari.com.br/aprenda-a-tecnica-branch-and-bound-com-python-otimize-seus-algoritmos/).
>> Aguardando atualizações <<


